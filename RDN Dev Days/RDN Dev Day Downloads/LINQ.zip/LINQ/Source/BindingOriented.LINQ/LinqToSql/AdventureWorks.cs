namespace LinqToSql
{
    partial class Contact
    {

    }

    partial class AdventureWorksDataContext
    {
    }
}
