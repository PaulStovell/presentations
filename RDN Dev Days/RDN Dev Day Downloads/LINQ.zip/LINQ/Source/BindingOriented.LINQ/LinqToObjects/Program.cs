﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using LinqToObjects.ObjectModel;

namespace LinqToObjects
{
    internal class Program
    {
        internal static void Main(string[] args)
        {

            Console.ReadKey();
        }
    }
}
